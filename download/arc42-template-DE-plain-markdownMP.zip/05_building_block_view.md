Bausteinsicht
=============

Whitebox Gesamtsystem
---------------------

### *Baustein 1* (Blackbox)

### *Baustein 2* (Blackbox)

### *Baustein n* (Blackbox)

Ebene 2
-------

### *Baustein 1* (Whitebox)

#### *Baustein 1.1* (Blackbox)

#### *Baustein 1.2* (Blackbox)

#### *Baustein 1.n* (Blackbox)

### *Baustein 2* (Whitebox)

#### *Baustein 2.1* (Blackbox)

#### *Baustein 2.2* (Blackbox)

#### *Baustein 2.n* (Blackbox)

### *Baustein 3* (Whitebox)

*\<Hier Whitebox-Erläuterung für Baustein 3 einfügen\>*

#### *Baustein 3.1* (Blackbox)

#### *Baustein 3.2* (Blackbox)

#### *Baustein 3.n* (Blackbox)

Ebene 3
-------

### *Baustein 1.1* (Whitebox)

#### *Baustein 1.1.1* (Blackbox)

#### *Baustein 1.1.2* (Blackbox)
