Entwurfsentscheidungen
======================

Entwurfsentscheidung 1
----------------------

### Fragestellung

### Rahmenbedingungen

### Annahmen

### Entscheidungskriterien

### Betrachtete Alternativen

### Entscheidung

…

Entwurfsentscheidung n
----------------------
