Über arc42
==========

arc42, das Template zur Dokumentation von Software- und
Systemarchitekturen.

Erstellt von Dr. Gernot Starke, Dr. Peter Hruschka und Mitwirkenden.

Template Revision: 6.5 DE (asciidoc-basiert), Juni 2014

© We acknowledge that this document uses material from the arc 42
architecture template, <http://www.arc42.de>. Created by Dr. Peter
Hruschka & Dr. Gernot Starke. For additional contributors see
<http://arc42.de/sonstiges/contributors.html>

> **Note**
>
> Diese Version des Templates enthält Hilfen und Erläuterungen. Sie
> dient der Einarbeitung in arc42 sowie dem Verständnis der Konzepte.
> Für die Dokumentation eigener System verwenden Sie besser die *plain*
> Version.

Einführung und Ziele
====================

(engl.: Introduction and Goals)

Als Einführung in das Architekturdokument gehören hierher die treibenden
Kräfte, die Software-Architekten bei ihren Entscheidungen
berücksichtigen müssen: Einerseits die Erfüllung bestimmter fachlicher
Aufgabenstellungen der Stakeholder, darüber hinaus aber die Erfüllung
oder Einhaltung der vorgegebenen Randbedingungen (required constraints)
unter Berücksichtigung der Architekturziele.

Aufgabenstellung
----------------

(engl.: Requirements Overview)

Qualitätsziele
--------------

(engl.: Quality Goals)

Stakeholder
-----------

Die folgende Tabelle zeigt Ihre konkreten Stakeholder für das System
sowie deren Interessen oder Beteiligung.

+-------------------------+-------------------------------------------------+
| Rolle                   | Beschreibung                                    |
+=========================+=================================================+
| Ziel / Intention        | Kontakt                                         |
+-------------------------+-------------------------------------------------+

: Stakeholder des Systems

Randbedingungen
===============

(engl.: Architecture Constraints)

Technische Randbedingungen
--------------------------

+-------------------------+-------------------------------------------------+
| Hardware-Vorgaben       |
+=========================+=================================================+
|                         | *Randbedingung~1~*                              |
+-------------------------+-------------------------------------------------+
|                         | *Randbedingung~2~*                              |
+-------------------------+-------------------------------------------------+
| **Software-Vorgaben**   |
+-------------------------+-------------------------------------------------+
|                         | *Randbedingung~i~*                              |
+-------------------------+-------------------------------------------------+
| **Vorgaben des          |
| Systembetriebs**        |
+-------------------------+-------------------------------------------------+
|                         | *Randbedingung~j~*                              |
+-------------------------+-------------------------------------------------+
| **Programmiervorgaben** |
+-------------------------+-------------------------------------------------+
|                         | *Randbedingung~k~*                              |
+-------------------------+-------------------------------------------------+

: Technische Randbedingungen

Organisatorische Randbedingungen
--------------------------------

### Organisation und Struktur

*\<hier Randbedingungen einfügen\>*

### Ressourcen (Budget, Zeit, Personal)

*\<hier Randbedingungen einfügen\>*

### Organisatorische Standards

*\<hier Randbedingungen einfügen\>*

### Juristische Faktoren

*\<hier Randbedingungen einfügen\>*

Konventionen
------------

Kontextabgrenzung
=================

Die folgenden Unterkapitel zeigen die Einbettung unseres Systems in
seine Umgebung.

Fachlicher Kontext
------------------

Technischer- oder Verteilungskontext
------------------------------------

Externe Schnittstellen
----------------------

Lösungsstrategie
================

Bausteinsicht
=============

Whitebox Gesamtsystem
---------------------

*Bausteinname* Whitebox

Übersicht / Struktur
:   *Die folgende Abbildung zeigt die inneren Bestandteile von
    \_Bausteinname* und deren Abhängigkeiten.

*\<hier Überblicksdiagramm einfügen\>*

Begründung
:   *Begründen oder erläutern Sie die Struktur*

Enthaltene Bausteine
:   *hier beschreiben Sie (kurz) Name und Zweck der enhaltenen
    Bausteine*

+----------------+-----------------------------------------------------------+
| Baustein 1     | Beschreibung 1                                            |
+----------------+-----------------------------------------------------------+
| Verweis auf    | Baustein 2                                                |
| Blackbox-Besch |                                                           |
| reibung        |                                                           |
+----------------+-----------------------------------------------------------+
|  Beschreibung  | Verweis auf Blackbox-Beschreibung                         |
| 2              |                                                           |
+----------------+-----------------------------------------------------------+
| Baustein 3     | Beschreibung 3                                            |
+----------------+-----------------------------------------------------------+

Schnittstellen
:   *hier beschreiben Sie (kurz) Name und Zweck der (internen+externen)
    Schnittstellen der Bausteine.*

+----------------+-----------------------------------------------------------+
| Schnittstelle  | Beschreibung 1                                            |
| 1              |                                                           |
+----------------+-----------------------------------------------------------+
| Schnittstelle  |  Beschreibung 2                                           |
| 2              |                                                           |
+----------------+-----------------------------------------------------------+
| Schnittstelle  | Beschreibung 3                                            |
| 3              |                                                           |
+----------------+-----------------------------------------------------------+

### *Baustein 1* (Blackbox)

*Bausteinname* Blackboxbeschreibung

**Zweck:** *hier beschreiben Sie Zweck oder Verantwortung des Bausteins*

+-------------------------+-------------------------------------------------+
| Schnittstelle 1         | Beschreibung 1                                  |
+-------------------------+-------------------------------------------------+
| Schnittstelle 2         |  Beschreibung 2                                 |
+-------------------------+-------------------------------------------------+
| Schnittstelle 3         | Beschreibung 3                                  |
+-------------------------+-------------------------------------------------+

: Schnittstellen *Bausteinname*:

**Ablageort/Datei:** *Verweisen Sie auf den Einstieg in den Sourcecode,
den/die Paket-/Modulnamen oder die wichtigsten Klassen*

*Bausteinname* Blackboxbeschreibung

**Zweck:** *hier beschreiben Sie Zweck oder Verantwortung des Bausteins*

+-------------------------+-------------------------------------------------+
| Schnittstelle 1         | Beschreibung 1                                  |
+-------------------------+-------------------------------------------------+
| Schnittstelle 2         |  Beschreibung 2                                 |
+-------------------------+-------------------------------------------------+
| Schnittstelle 3         | Beschreibung 3                                  |
+-------------------------+-------------------------------------------------+

: Schnittstellen *Bausteinname*

**Ablageort/Datei:** *Verweisen Sie auf den Einstieg in den Sourcecode,
den/die Paket-/Modulnamen oder die wichtigsten Klassen*

+-------------------------+-------------------------------------------------+
| Anforderung 1           | Bemerkung 1                                     |
+-------------------------+-------------------------------------------------+
| Anforderung 2           |  Bemerkung 2                                    |
+-------------------------+-------------------------------------------------+
| Anforderung 3           | Bemerkung 3                                     |
+-------------------------+-------------------------------------------------+

: Erfüllte Anforderungen

**Variabilität:** *hier beschreiben Sie, in welchen Aspekten der
Baustein variabel, flexibel oder konfigurierbar ist.*

+-------------------------+-------------------------------------------------+
| OP 1                    | Bemerkung 1                                     |
+-------------------------+-------------------------------------------------+
| OP 2                    |  Bemerkung 2                                    |
+-------------------------+-------------------------------------------------+
| OP 3                    | Bemerkung 3                                     |
+-------------------------+-------------------------------------------------+

: Offene Punkte

+-------------------------+-------------------------------------------------+
| Version                 | Bemerkung 1                                     |
+-------------------------+-------------------------------------------------+
| Autor                   |  Bemerkung 2                                    |
+-------------------------+-------------------------------------------------+
| Änderungsdatum          | Bemerkung 3                                     |
+-------------------------+-------------------------------------------------+
| (…)                     | …                                               |
+-------------------------+-------------------------------------------------+

: Organisatorisches

### *Baustein 2* (Blackbox)

*Bausteinname* Blackboxbeschreibung

**Zweck:** *hier beschreiben Sie Zweck oder Verantwortung des Bausteins*

+-------------------------+-------------------------------------------------+
| Schnittstelle 1         | Beschreibung 1                                  |
+-------------------------+-------------------------------------------------+
| Schnittstelle 2         |  Beschreibung 2                                 |
+-------------------------+-------------------------------------------------+
| Schnittstelle 3         | Beschreibung 3                                  |
+-------------------------+-------------------------------------------------+

: Schnittstellen *Bausteinname*:

**Ablageort/Datei:** *Verweisen Sie auf den Einstieg in den Sourcecode,
den/die Paket-/Modulnamen oder die wichtigsten Klassen*

### *Baustein n* (Blackbox)

*Bausteinname* Blackboxbeschreibung

**Zweck:** *hier beschreiben Sie Zweck oder Verantwortung des Bausteins*

+-------------------------+-------------------------------------------------+
| Schnittstelle 1         | Beschreibung 1                                  |
+-------------------------+-------------------------------------------------+
| Schnittstelle 2         |  Beschreibung 2                                 |
+-------------------------+-------------------------------------------------+
| Schnittstelle 3         | Beschreibung 3                                  |
+-------------------------+-------------------------------------------------+

: Schnittstellen *Bausteinname*:

**Ablageort/Datei:** *Verweisen Sie auf den Einstieg in den Sourcecode,
den/die Paket-/Modulnamen oder die wichtigsten Klassen*

Ebene 2
-------

### *Baustein 1* (Whitebox)

*Bausteinname* Whitebox

Übersicht / Struktur
:   *Die folgende Abbildung zeigt die inneren Bestandteile von
    \_Bausteinname* und deren Abhängigkeiten.

*\<hier Überblicksdiagramm einfügen\>*

Begründung
:   *Begründen oder erläutern Sie die Struktur*

Enthaltene Bausteine
:   *hier beschreiben Sie (kurz) Name und Zweck der enhaltenen
    Bausteine*

+----------------+-----------------------------------------------------------+
| Baustein 1     | Beschreibung 1                                            |
+----------------+-----------------------------------------------------------+
| Verweis auf    | Baustein 2                                                |
| Blackbox-Besch |                                                           |
| reibung        |                                                           |
+----------------+-----------------------------------------------------------+
|  Beschreibung  | Verweis auf Blackbox-Beschreibung                         |
| 2              |                                                           |
+----------------+-----------------------------------------------------------+
| Baustein 3     | Beschreibung 3                                            |
+----------------+-----------------------------------------------------------+

Schnittstellen
:   *hier beschreiben Sie (kurz) Name und Zweck der (internen+externen)
    Schnittstellen der Bausteine.*

+----------------+-----------------------------------------------------------+
| Schnittstelle  | Beschreibung 1                                            |
| 1              |                                                           |
+----------------+-----------------------------------------------------------+
| Schnittstelle  |  Beschreibung 2                                           |
| 2              |                                                           |
+----------------+-----------------------------------------------------------+
| Schnittstelle  | Beschreibung 3                                            |
| 3              |                                                           |
+----------------+-----------------------------------------------------------+

#### *Baustein 1.1* (Blackbox)

*Bausteinname* Blackboxbeschreibung

**Zweck:** *hier beschreiben Sie Zweck oder Verantwortung des Bausteins*

+-------------------------+-------------------------------------------------+
| Schnittstelle 1         | Beschreibung 1                                  |
+-------------------------+-------------------------------------------------+
| Schnittstelle 2         |  Beschreibung 2                                 |
+-------------------------+-------------------------------------------------+
| Schnittstelle 3         | Beschreibung 3                                  |
+-------------------------+-------------------------------------------------+

: Schnittstellen *Bausteinname*:

**Ablageort/Datei:** *Verweisen Sie auf den Einstieg in den Sourcecode,
den/die Paket-/Modulnamen oder die wichtigsten Klassen*

#### *Baustein 1.2* (Blackbox)

*Bausteinname* Blackboxbeschreibung

**Zweck:** *hier beschreiben Sie Zweck oder Verantwortung des Bausteins*

+-------------------------+-------------------------------------------------+
| Schnittstelle 1         | Beschreibung 1                                  |
+-------------------------+-------------------------------------------------+
| Schnittstelle 2         |  Beschreibung 2                                 |
+-------------------------+-------------------------------------------------+
| Schnittstelle 3         | Beschreibung 3                                  |
+-------------------------+-------------------------------------------------+

: Schnittstellen *Bausteinname*:

**Ablageort/Datei:** *Verweisen Sie auf den Einstieg in den Sourcecode,
den/die Paket-/Modulnamen oder die wichtigsten Klassen*

#### *Baustein 1.n* (Blackbox)

*Bausteinname* Blackboxbeschreibung

**Zweck:** *hier beschreiben Sie Zweck oder Verantwortung des Bausteins*

+-------------------------+-------------------------------------------------+
| Schnittstelle 1         | Beschreibung 1                                  |
+-------------------------+-------------------------------------------------+
| Schnittstelle 2         |  Beschreibung 2                                 |
+-------------------------+-------------------------------------------------+
| Schnittstelle 3         | Beschreibung 3                                  |
+-------------------------+-------------------------------------------------+

: Schnittstellen *Bausteinname*:

**Ablageort/Datei:** *Verweisen Sie auf den Einstieg in den Sourcecode,
den/die Paket-/Modulnamen oder die wichtigsten Klassen*

### *Baustein 2* (Whitebox)

*Bausteinname* Whitebox

Übersicht / Struktur
:   *Die folgende Abbildung zeigt die inneren Bestandteile von
    \_Bausteinname* und deren Abhängigkeiten.

*\<hier Überblicksdiagramm einfügen\>*

Begründung
:   *Begründen oder erläutern Sie die Struktur*

Enthaltene Bausteine
:   *hier beschreiben Sie (kurz) Name und Zweck der enhaltenen
    Bausteine*

+----------------+-----------------------------------------------------------+
| Baustein 1     | Beschreibung 1                                            |
+----------------+-----------------------------------------------------------+
| Verweis auf    | Baustein 2                                                |
| Blackbox-Besch |                                                           |
| reibung        |                                                           |
+----------------+-----------------------------------------------------------+
|  Beschreibung  | Verweis auf Blackbox-Beschreibung                         |
| 2              |                                                           |
+----------------+-----------------------------------------------------------+
| Baustein 3     | Beschreibung 3                                            |
+----------------+-----------------------------------------------------------+

Schnittstellen
:   *hier beschreiben Sie (kurz) Name und Zweck der (internen+externen)
    Schnittstellen der Bausteine.*

+----------------+-----------------------------------------------------------+
| Schnittstelle  | Beschreibung 1                                            |
| 1              |                                                           |
+----------------+-----------------------------------------------------------+
| Schnittstelle  |  Beschreibung 2                                           |
| 2              |                                                           |
+----------------+-----------------------------------------------------------+
| Schnittstelle  | Beschreibung 3                                            |
| 3              |                                                           |
+----------------+-----------------------------------------------------------+

#### *Baustein 2.1* (Blackbox)

*Bausteinname* Blackboxbeschreibung

**Zweck:** *hier beschreiben Sie Zweck oder Verantwortung des Bausteins*

+-------------------------+-------------------------------------------------+
| Schnittstelle 1         | Beschreibung 1                                  |
+-------------------------+-------------------------------------------------+
| Schnittstelle 2         |  Beschreibung 2                                 |
+-------------------------+-------------------------------------------------+
| Schnittstelle 3         | Beschreibung 3                                  |
+-------------------------+-------------------------------------------------+

: Schnittstellen *Bausteinname*:

**Ablageort/Datei:** *Verweisen Sie auf den Einstieg in den Sourcecode,
den/die Paket-/Modulnamen oder die wichtigsten Klassen*

#### *Baustein 2.2* (Blackbox)

*Bausteinname* Blackboxbeschreibung

**Zweck:** *hier beschreiben Sie Zweck oder Verantwortung des Bausteins*

+-------------------------+-------------------------------------------------+
| Schnittstelle 1         | Beschreibung 1                                  |
+-------------------------+-------------------------------------------------+
| Schnittstelle 2         |  Beschreibung 2                                 |
+-------------------------+-------------------------------------------------+
| Schnittstelle 3         | Beschreibung 3                                  |
+-------------------------+-------------------------------------------------+

: Schnittstellen *Bausteinname*:

**Ablageort/Datei:** *Verweisen Sie auf den Einstieg in den Sourcecode,
den/die Paket-/Modulnamen oder die wichtigsten Klassen*

#### *Baustein 2.n* (Blackbox)

*Bausteinname* Blackboxbeschreibung

**Zweck:** *hier beschreiben Sie Zweck oder Verantwortung des Bausteins*

+-------------------------+-------------------------------------------------+
| Schnittstelle 1         | Beschreibung 1                                  |
+-------------------------+-------------------------------------------------+
| Schnittstelle 2         |  Beschreibung 2                                 |
+-------------------------+-------------------------------------------------+
| Schnittstelle 3         | Beschreibung 3                                  |
+-------------------------+-------------------------------------------------+

: Schnittstellen *Bausteinname*:

**Ablageort/Datei:** *Verweisen Sie auf den Einstieg in den Sourcecode,
den/die Paket-/Modulnamen oder die wichtigsten Klassen*

### *Baustein 3* (Whitebox)

*\<Hier Whitebox-Erläuterung für Baustein 3 einfügen\>*

#### *Baustein 3.1* (Blackbox)

*Bausteinname* Blackboxbeschreibung

**Zweck:** *hier beschreiben Sie Zweck oder Verantwortung des Bausteins*

+-------------------------+-------------------------------------------------+
| Schnittstelle 1         | Beschreibung 1                                  |
+-------------------------+-------------------------------------------------+
| Schnittstelle 2         |  Beschreibung 2                                 |
+-------------------------+-------------------------------------------------+
| Schnittstelle 3         | Beschreibung 3                                  |
+-------------------------+-------------------------------------------------+

: Schnittstellen *Bausteinname*:

**Ablageort/Datei:** *Verweisen Sie auf den Einstieg in den Sourcecode,
den/die Paket-/Modulnamen oder die wichtigsten Klassen*

#### *Baustein 3.2* (Blackbox)

*Bausteinname* Blackboxbeschreibung

**Zweck:** *hier beschreiben Sie Zweck oder Verantwortung des Bausteins*

+-------------------------+-------------------------------------------------+
| Schnittstelle 1         | Beschreibung 1                                  |
+-------------------------+-------------------------------------------------+
| Schnittstelle 2         |  Beschreibung 2                                 |
+-------------------------+-------------------------------------------------+
| Schnittstelle 3         | Beschreibung 3                                  |
+-------------------------+-------------------------------------------------+

: Schnittstellen *Bausteinname*:

**Ablageort/Datei:** *Verweisen Sie auf den Einstieg in den Sourcecode,
den/die Paket-/Modulnamen oder die wichtigsten Klassen*

#### *Baustein 3.n* (Blackbox)

*Bausteinname* Blackboxbeschreibung

**Zweck:** *hier beschreiben Sie Zweck oder Verantwortung des Bausteins*

+-------------------------+-------------------------------------------------+
| Schnittstelle 1         | Beschreibung 1                                  |
+-------------------------+-------------------------------------------------+
| Schnittstelle 2         |  Beschreibung 2                                 |
+-------------------------+-------------------------------------------------+
| Schnittstelle 3         | Beschreibung 3                                  |
+-------------------------+-------------------------------------------------+

: Schnittstellen *Bausteinname*:

**Ablageort/Datei:** *Verweisen Sie auf den Einstieg in den Sourcecode,
den/die Paket-/Modulnamen oder die wichtigsten Klassen*

Ebene 3
-------

### *Baustein 1.1* (Whitebox)

*Bausteinname* Whitebox

Übersicht / Struktur
:   *Die folgende Abbildung zeigt die inneren Bestandteile von
    \_Bausteinname* und deren Abhängigkeiten.

*\<hier Überblicksdiagramm einfügen\>*

Begründung
:   *Begründen oder erläutern Sie die Struktur*

Enthaltene Bausteine
:   *hier beschreiben Sie (kurz) Name und Zweck der enhaltenen
    Bausteine*

+----------------+-----------------------------------------------------------+
| Baustein 1     | Beschreibung 1                                            |
+----------------+-----------------------------------------------------------+
| Verweis auf    | Baustein 2                                                |
| Blackbox-Besch |                                                           |
| reibung        |                                                           |
+----------------+-----------------------------------------------------------+
|  Beschreibung  | Verweis auf Blackbox-Beschreibung                         |
| 2              |                                                           |
+----------------+-----------------------------------------------------------+
| Baustein 3     | Beschreibung 3                                            |
+----------------+-----------------------------------------------------------+

Schnittstellen
:   *hier beschreiben Sie (kurz) Name und Zweck der (internen+externen)
    Schnittstellen der Bausteine.*

+----------------+-----------------------------------------------------------+
| Schnittstelle  | Beschreibung 1                                            |
| 1              |                                                           |
+----------------+-----------------------------------------------------------+
| Schnittstelle  |  Beschreibung 2                                           |
| 2              |                                                           |
+----------------+-----------------------------------------------------------+
| Schnittstelle  | Beschreibung 3                                            |
| 3              |                                                           |
+----------------+-----------------------------------------------------------+

#### *Baustein 1.1.1* (Blackbox)

*Bausteinname* Blackboxbeschreibung

**Zweck:** *hier beschreiben Sie Zweck oder Verantwortung des Bausteins*

+-------------------------+-------------------------------------------------+
| Schnittstelle 1         | Beschreibung 1                                  |
+-------------------------+-------------------------------------------------+
| Schnittstelle 2         |  Beschreibung 2                                 |
+-------------------------+-------------------------------------------------+
| Schnittstelle 3         | Beschreibung 3                                  |
+-------------------------+-------------------------------------------------+

: Schnittstellen *Bausteinname*:

**Ablageort/Datei:** *Verweisen Sie auf den Einstieg in den Sourcecode,
den/die Paket-/Modulnamen oder die wichtigsten Klassen*

#### *Baustein 1.1.2* (Blackbox)

*Bausteinname* Blackboxbeschreibung

**Zweck:** *hier beschreiben Sie Zweck oder Verantwortung des Bausteins*

+-------------------------+-------------------------------------------------+
| Schnittstelle 1         | Beschreibung 1                                  |
+-------------------------+-------------------------------------------------+
| Schnittstelle 2         |  Beschreibung 2                                 |
+-------------------------+-------------------------------------------------+
| Schnittstelle 3         | Beschreibung 3                                  |
+-------------------------+-------------------------------------------------+

: Schnittstellen *Bausteinname*:

**Ablageort/Datei:** *Verweisen Sie auf den Einstieg in den Sourcecode,
den/die Paket-/Modulnamen oder die wichtigsten Klassen*

Laufzeitsicht
=============

Laufzeitszenario 1
------------------

Laufzeitszenario 2
------------------

…

Laufzeitszenario *n*
--------------------

Verteilungssicht
================

Infrastruktur Ebene 1
---------------------

### Verteilungsdiagramm Ebene 1

### Prozessor 1

### Prozessor 2

…

### Prozessor *n*

### Kanal 1

### Kanal 2

…

### Kanal *m*

### Offene Punkte

Infrastruktur Ebene 2
---------------------

Konzepte
========

Fachliche Strukturen und Modelle
--------------------------------

Typische Muster und Strukturen
------------------------------

Persistenz
----------

Benutzungsoberfläche
--------------------

Ergonomie
---------

Ablaufsteuerung
---------------

Transaktionsbehandlung
----------------------

Sessionbehandlung
-----------------

Sicherheit
----------

Kommunikation und Integration mit anderen IT-Systemen
-----------------------------------------------------

Verteilung
----------

Plausibilisierung und Validierung
---------------------------------

Ausnahme-/Fehlerbehandlung
--------------------------

Management des Systems & Administrierbarkeit
--------------------------------------------

Logging, Protokollierung, Tracing
---------------------------------

Geschäftsregeln
---------------

Konfigurierbarkeit
------------------

Parallelisierung und Threading
------------------------------

Internationalisierung
---------------------

Migration
---------

Testbarkeit
-----------

Skalierung, Clustering
----------------------

Hochverfügbarkeit
-----------------

Codegenerierung
---------------

Buildmanagement
---------------

Stapel-/Batchverarbeitung
-------------------------

Drucken
-------

Reporting
---------

Archivierung
------------

Entwurfsentscheidungen
======================

Entwurfsentscheidung 1
----------------------

### Fragestellung

### Rahmenbedingungen

### Annahmen

### Entscheidungskriterien

### Betrachtete Alternativen

### Entscheidung

…

Entwurfsentscheidung n
----------------------

Qualitätsszenarien
==================

Qualitätsbaum
-------------

Bewertungsszenarien
-------------------

  Szenario                Auslöser                Metrik
  ----------------------- ----------------------- -----------------------
                                                  
                                                  

  : Bewertungsszenarien

Risiken
=======

+-------------------------+-------------------------------------------------+
| Risiko                  | Priorität                                       |
+=========================+=================================================+
| Konsequenz              | Erläuterung                                     |
+-------------------------+-------------------------------------------------+
+-------------------------+-------------------------------------------------+
+-------------------------+-------------------------------------------------+
+-------------------------+-------------------------------------------------+
+-------------------------+-------------------------------------------------+

: Risiken

Glossar
=======

+-------------------------+-------------------------------------------------+
| Begriff                 | Definition                                      |
+=========================+=================================================+
| \<Begriff-1             | Beschreibung-2                                  |
+-------------------------+-------------------------------------------------+
| \<Begriff-2             | Beschreibung-2                                  |
+-------------------------+-------------------------------------------------+

: Glossar

Literatur und Verweise
======================

Starke-2014
:   Gernot Starke: Effektive Softwarearchitekturen - Ein praktischer
    Leitfaden. Carl Hanser Verlag, 6, Auflage 2014.

Starke-Hruschka-2011
:   Gernot Starke und Peter Hruschka: Softwarearchitektur kompakt.
    Springer Akademischer Verlag, 2. Auflage 2011.

Zörner-2013
:   Softwarearchitekturen dokumentieren und kommunizieren, Carl Hanser
    Verlag, 2012

Beispiele
=========

-   [HTML Sanity
    Checker](http://aim42.github.io/htmlSanityCheck/hsc_arc42.html)
    (englisch)

-   [DocChess](http://www.dokchess.de/dokchess/arc42/)

-   [Gradle](http://www.embarc.de/arc42-starschnitt-gradle/)

-   [MaMa CRM](http://arc42.org:8090/display/arc42beispielmamacrm)

-   [Financial Data
    Migration](http://confluence.arc42.org/display/migrationEg/Financial+Data+Migration)

Danksagung + Mitwirkung
=======================

arc42 stammt ursprünglich von [Dr. Peter Hruschka](http://b-agile.de)
und [Dr. Gernot Starke](http://gernotstarke.de).

Quellen
:   Wir pflegen arc42 zur Zeit im *asciidoc* Format, gehosted bei
    [GitHub unter der
    arc42-Organisation](https://github.com/aim42/aim42).

Issues
:   Wir pflegen eine Liste [offener Punkte und
    Fehler](https://github.com/arc42/arc42-template/issues).

Wir freuen uns, wenn Sie Fehler/Unklarheiten in einem Fork korrigieren
und uns einen *pull request* schicken!

Mitwirkende
-----------

Wir danken ausdrücklich allen aktiven und früheren Mitwirkenden sowie
den zahlreichen (anonymen) Ratgebern, Fehlerfindern und Anwendern für
Ihre Hilfe und Unterstützung.

### Zur Zeit aktiv

-   Gernot Starke

-   Stefan Zörner

-   Markus Schärtel

-   Ralf D. Müller

-   Peter Hruschka

-   Jürgen Krey

### Frühere Mitwirkende

(in alfabetischer Reihenfolge)

-   Anne Aloysius

-   Matthias Bohlen

-   Karl Eilebrecht

-   Manfred Ferken

-   Phillip Ghadir

-   Carsten Klein

-   Prof. Arne Koschel

-   Axel Scheithauer

Approved Practitioner for arc42
===============================

(TODO)

