Beispiele
=========

-   [HTML Sanity
    Checker](http://aim42.github.io/htmlSanityCheck/hsc_arc42.html)
    (englisch)

-   [DocChess](http://www.dokchess.de/dokchess/arc42/)

-   [Gradle](http://www.embarc.de/arc42-starschnitt-gradle/)

-   [MaMa CRM](http://arc42.org:8090/display/arc42beispielmamacrm)

-   [Financial Data
    Migration](http://confluence.arc42.org/display/migrationEg/Financial+Data+Migration)


