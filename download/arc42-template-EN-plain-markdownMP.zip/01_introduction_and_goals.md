Introduction and Goals
======================

The introduction to the architecture documentation should list the
driving forces that software architects must consider in their
decisions. This includes on the one hand the fulfillment of functional
requirements of the stakeholders, on the other hand the fulfillment of
or compliance with required constraints, always in consideration of the
architecture goals.

Requirements Overview
---------------------

Quality Goals
-------------

Stakeholders
------------
