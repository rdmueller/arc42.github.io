Examples
========

-   [HTML Sanity
    Checker](http://aim42.github.io/htmlSanityCheck/hsc_arc42.html)

-   [DocChess](http://www.dokchess.de/dokchess/arc42/) (german)

-   [Gradle](http://www.embarc.de/arc42-starschnitt-gradle/) (german)

-   [MaMa CRM](http://arc42.org:8090/display/arc42beispielmamacrm)
    (german)

-   [Financial Data
    Migration](http://confluence.arc42.org/display/migrationEg/Financial+Data+Migration)
    (german)


