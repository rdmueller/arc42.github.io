*BuildingBlockName* Blackbox description

**Purpose:** *describe here Purpose and Responsibilities of this
building block*

+-------------------------+-------------------------------------------------+
| Interface 1             | Description 1                                   |
+-------------------------+-------------------------------------------------+
| Interface 2             |  Description 2                                  |
+-------------------------+-------------------------------------------------+
| Interface 3             | Description 3                                   |
+-------------------------+-------------------------------------------------+

: Interfaces *BuildingBlockName*

**Related Locations/Files:** *Point to a relevant starting point in
source code, or name packages or modules of the most relevant classes to
this building block*

